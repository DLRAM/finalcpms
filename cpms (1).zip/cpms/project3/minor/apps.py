from django.apps import AppConfig


class MinorConfig(AppConfig):
    name = 'minor'
